package jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
public class ConnDB {
    static Connection cn;
    PreparedStatement pst;
    static Connection conn() throws Exception{ 
        Class.forName("com.mysql.jdbc.Driver");
        cn=DriverManager.getConnection("jdbc:mysql://localhost/procat","root","");
        return cn; 
    }
}